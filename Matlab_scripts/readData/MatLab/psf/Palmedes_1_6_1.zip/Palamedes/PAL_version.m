%
%PAL_version   PAL_version displays the version number of Palamedes.
%
disp(sprintf('\nThis is Palamedes version 1.6.1 Released: December 20, 2013\n'));
disp(sprintf('The Palamedes toolbox is a set of free routines for analyzing'))
disp(sprintf('psychophysical data written and made available by Nick Prins and'))
disp(sprintf('Fred Kingdom.\n'));
disp(sprintf('Citation: \nPrins, N. & Kingdom, F.A.A. Palamedes: Matlab routines for'));
disp(sprintf('analyzing psychophysical data. http://www.palamedestoolbox.org.\n'));
disp(sprintf('www.palamedestoolbox.org'));
disp(sprintf('palamedes@palamedestoolbox.org'));