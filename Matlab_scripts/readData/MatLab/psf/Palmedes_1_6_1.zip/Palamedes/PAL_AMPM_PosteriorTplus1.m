%
%PAL_AMPM_PosteriorTplus1  Derives posterior distributions for combinations
%   of stimulus intensity and response on trial T + 1 in psi method 
%   adaptive procedure.
%   
%   syntax: [PosteriorTplus1givenSuccess PosteriorTplus1givenFailure ...
%       pSuccessGivenx] = PAL_AMPM_PosteriorTplus1(pdf, PFLookUpTable)
%
%   Internal function
%
%Introduced: Palamedes version 1.0.0 (NP)
%Modified: Palamedes version 1.5.0, 1.6.1 (see History.m)

function [PosteriorTplus1givenSuccess, PosteriorTplus1givenFailure, pSuccessGivenx] = PAL_AMPM_PosteriorTplus1(pdf, PFLookUpTable)

pdf5D = repmat(pdf, [1 1 1 1 size(PFLookUpTable,5)]);
pSuccessGivenx = sum(sum(sum(sum(pdf5D.*PFLookUpTable,1),2),3),4);

PosteriorTplus1givenSuccess = pdf5D.*PFLookUpTable;
PosteriorTplus1givenFailure = pdf5D-PosteriorTplus1givenSuccess;

PosteriorTplus1givenSuccess = bsxfun(@rdivide,PosteriorTplus1givenSuccess,sum(sum(sum(sum(PosteriorTplus1givenSuccess,1),2),3),4));
PosteriorTplus1givenFailure = bsxfun(@rdivide,PosteriorTplus1givenFailure,sum(sum(sum(sum(PosteriorTplus1givenFailure,1),2),3),4));