% ParametrizeSlopes Reparametrizes slopes of PFs for
%   PAL_PFLR_CustomDefine_Demo.
%
%NP (November 2009)

function betas = ParametrizeSlopes(params)

betas(1:8) = params(1)-params(2);
betas(9:16) = params(1)+params(2);